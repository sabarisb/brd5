package com.demo.service;

import java.util.List;

import javax.management.loading.ClassLoaderRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import com.demo.dao.CustomerDAO;
import com.demo.entity.Customer;

@Service
public class CustomerServiceImpl<CustomerDetails> implements CustomerService {
	// need to inject customer dao
	@Autowired
	private CustomerDAO customerDAO;

	@Override
	@Transactional
	public List<Customer> getCustomers() {
		return customerDAO.getCustomers();
	}

	@Override
	@Transactional
	public void saveCustomer(Customer theCustomer) {

		customerDAO.saveCustomer(theCustomer);
	}

	@Override
	@Transactional
	public Customer getCustomer(int Customer_id) {
		
		return customerDAO.getCustomer(Customer_id);
	}

	@Override
	@Transactional
	public void deleteCustomer(int Customer_id) {

		customerDAO.deleteCustomer(Customer_id);
	}

@Override
public void update(Model model, CustomerDetails customerDetails) {
	model.addAttribute("customerDetails",ClassLoaderRepository.findByCustomerCode(customerDetails.getCustomerCode()));
	
}


public void search(Model model,CustomerDetails customerDetails) {
model.addAttribute("search", customerRepository.findByCustomerCode(customerDetails.getCustomerCode()));

}
@Override
public void delete(Model model,CustomerDetails customerDetails) {
customerRepository.deleteById(customerDetails);
model.addAttribute("delete", customerRepository.deleteByCustomerCode(customerDetails.getCustomerCode()));
customerRepository.delete(customerDetails);
}
